var angualarModule = angular.module("angualarModule", ["ng.ckeditor"]);

angualarModule.controller("indexController", function ($scope) {
    $scope.ckModel = "";
    $scope.ckModelTwo = "";
    $scope.toolOptions = {

        readOnly: false,
        removePlugins: 'elementspath,magicline,contextmenu,scayt,liststyle,tabletools,tableselection',
        font_names: 'Arial;Calibri;Courier New;Georgia;Lucida Sans Unicode;Tahoma;Times New Roman;Trebuchet MS;Verdana',
        format_tags: "p;h1;h2;h3;h4",
        font_defaultLabel: "Calibri",
        fontSize_defaultLabel: "14",
        height: "120",
        extraPlugins: 'flite,pastefromword',
        flite: {},
        disableNativeSpellChecker: false,
        on: {
            change: function (evt) {
               // debug.value = new Date() + ": Editable:" + evt.editor.editable() + "\n\n" + debug.value;
                var newData = evt.editor.getData();
               // debug.value = new Date() + ": Changed content: " + newData.trim() + "\n" + debug.value;
            },
            instanceReady: function (evt) {
               //debug.value = new Date() + ": Adding native event listener for input/insertReplacementText\n" + debug.value;
             
               evt.editor.editable().$.addEventListener("input", function (evt) {
               
                    if ("insertReplacementText" === evt.inputType) {
                     
                    //    debug.value = new Date() + ": Auto-Correct Event received\n" + debug.value;
                        window.setTimeout(function () {
                            editor.fire('saveSnapshot');
                        }, 0);
                    }
                });
            }
        }


    };

    function triggerChangeEvent(evt) {
        debugger;
        const editor = evt.editor;
        editor.editable().$.addEventListener('input', function (evt) {
            if ('insertReplacementText' === evt.inputType) {
                editor.fire('change');
            }
        });
    }


    var flite = $scope.toolOptions.flite = $scope.toolOptions.flite || {};
    flite.isTracking = false;
    flite.userName = "jameel";
    flite.userId = "1201";
    var userStyleId = Math.floor(Math.random() * 10) + 1;
    var tempstyle = ("{" + '"' + "Jameel" + '"' + ":" + userStyleId + "}");
    flite.userStyles = JSON.parse(tempstyle);
    flite.tooltips = {
        show: true,
        path: "js/opentip-adapter.js",
        classPath: "OpentipAdapter",
        cssPath: "css/opentip.css",
        delay: 500
    };
    flite.tooltipTemplate = "%a by %u ,";

})