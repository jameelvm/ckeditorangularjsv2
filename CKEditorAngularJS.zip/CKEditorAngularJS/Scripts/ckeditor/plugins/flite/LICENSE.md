Software License Agreement
==========================
<ul>
<li>Copyright (c) 2018 Loopindex.com
<li>Written by (David *)Frenkiel
</ul>
<h4>Commercial license</h4>
Details in next revision

